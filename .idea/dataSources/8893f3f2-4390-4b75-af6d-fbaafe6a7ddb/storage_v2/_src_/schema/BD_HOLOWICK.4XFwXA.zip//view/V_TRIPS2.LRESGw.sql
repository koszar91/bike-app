create view V_TRIPS2 as
SELECT country,
       trip_date,
       NAME,
       no_places,
       NO_AVAILABLE_PLACES

from TRIP
/

