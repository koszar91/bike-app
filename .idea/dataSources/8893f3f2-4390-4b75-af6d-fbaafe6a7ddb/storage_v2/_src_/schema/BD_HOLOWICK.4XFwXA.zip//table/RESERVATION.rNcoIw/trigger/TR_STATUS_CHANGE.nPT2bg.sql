create trigger TR_STATUS_CHANGE
    after update
    on RESERVATION
    for each row
begin

        insert into RESERVATIONLOG(RESERVATION_ID, RESERVATION_LOG_DATE, NEW_STATUS)
        values (:NEW.reservation_id, SYSDATE, :NEW.status);
        if(:NEW.status = 'C') then
            update TRIP
                set TRIP.NO_AVAILABLE_PLACES = TRIP.NO_AVAILABLE_PLACES + 1
            where TRIP_ID = :NEW.trip_id;
        end if;

    end;
/

