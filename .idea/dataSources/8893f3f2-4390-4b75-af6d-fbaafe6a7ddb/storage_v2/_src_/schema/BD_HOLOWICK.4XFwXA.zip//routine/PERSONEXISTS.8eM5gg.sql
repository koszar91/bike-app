create function personExists(person_id PERSON.PERSON_ID%TYPE)
return boolean
is
    counter int ;
begin
    select count(*)
    into counter
    from PERSON p
    where p.PERSON_ID = personExists.person_id;
    return counter>0;
end;
/

