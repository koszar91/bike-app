create function tripExists(trip_id IN number)
    return boolean
    is
    counter int;
begin
    select count(*) into counter from TRIP t where t.TRIP_ID=tripExists.trip_id;
    return counter>0;
end;
/

