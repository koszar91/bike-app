create function NoOfReservedPlaces(trip_id IN TRIP.TRIP_ID%TYPE)
return int
is counter int;
begin
    select (V_Trips.no_places - V_Trips.no_available_places)
    into counter
    from V_Trips
    inner join TRIP T on V_Trips.country = T.COUNTRY
    where T.TRIP_ID = NoOfReservedPlaces.trip_id;
    return counter;
end;
/

