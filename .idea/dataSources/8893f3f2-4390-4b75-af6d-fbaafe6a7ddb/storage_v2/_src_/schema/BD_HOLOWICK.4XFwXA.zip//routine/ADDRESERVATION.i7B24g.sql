create procedure AddReservation(trip_id IN RESERVATION.RESERVATION_ID%TYPE, person_id IN RESERVATION.PERSON_ID%TYPE )
is
    available_places int;
begin
    IF (tripExists(trip_id) = True and personExists(person_id) = True ) then
        select no_available_places
        into available_places
        from V_Trips;
        IF (available_places > 0 ) then
            insert into RESERVATION (TRIP_ID,PERSON_ID,STATUS)
            values ( AddReservation.trip_id , AddReservation.person_id,'N');
        else
            RAISE_APPLICATION_ERROR(-20001,'No available places');
        end if;
    else
        RAISE_APPLICATION_ERROR(-20001,'No such trip or person exist');

    end if;

end;
/

