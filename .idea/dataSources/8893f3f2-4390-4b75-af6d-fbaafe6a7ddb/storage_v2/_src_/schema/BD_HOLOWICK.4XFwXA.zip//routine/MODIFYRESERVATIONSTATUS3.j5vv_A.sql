create procedure ModifyReservationStatus3(reservation_id in RESERVATION.RESERVATION_ID%TYPE,
                                                    status in RESERVATION.STATUS%TYPE)
    is
    available_places int;

begin

    IF (reservationExists(reservation_id) = true) then

        select no_available_places
        into available_places
        from V_Trips
        inner join V_RESERVATIONS VR on V_TRIPS.COUNTRY = VR.COUNTRY and VR.RESERVATION_ID = ModifyReservationStatus3.reservation_id;

        IF (available_places > 0 ) then

            update RESERVATION r
                set r.STATUS = ModifyReservationStatus3.status
                where r.Reservation_id = ModifyReservationStatus3.reservation_id;

        elsif ( available_places = 0 and ModifyReservationStatus3.status = 'C' ) then

            update RESERVATION r
                set STATUS = ModifyReservationStatus3.status
                where r.Reservation_id = ModifyReservationStatus3.reservation_id;

        else
             RAISE_APPLICATION_ERROR(-20002,'No free places cannot change status');
        end if;
        else
        RAISE_APPLICATION_ERROR(-20002,'No such trip exist');
    end if;
end;
/

