create view V_TRIPS as
SELECT country,trip_date, NAME ,no_places,
                              (NO_PLACES - (select COUNT(*)
                              from RESERVATION
                                  where TRIP.TRIP_ID = RESERVATION.TRIP_ID
                                  and STATUS not like 'C'
                                  )) as  no_available_places

from TRIP
/

