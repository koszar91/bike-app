create FUNCTION PersonReservations(person_id IN number)
    return set_of_person_reservations as result set_of_person_reservations;
begin
    select  person_reservation(TRIP_ID,COUNTRY,TRIP_DATE,VR.STATUS)
    bulk collect
    into result
    from RESERVATION  r
    inner join V_RESERVATIONS VR on r.RESERVATION_ID = VR.RESERVATION_ID where r.PERSON_ID = PersonReservations.person_id;
    return result;

end;
/

