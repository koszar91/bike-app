create view V_AVAILABLETRIPS as
SELECT COUNTRY,
       TRIP_DATE,
       NAME,
       NO_PLACES,
       no_available_places
from V_Trips where trip_date > SYSDATE and no_available_places > 0
/

