create type person_reservation as object
    (
        trip_id int,
        country varchar2(64),
        trip_date DATE,
        status char(1)

    )
/

