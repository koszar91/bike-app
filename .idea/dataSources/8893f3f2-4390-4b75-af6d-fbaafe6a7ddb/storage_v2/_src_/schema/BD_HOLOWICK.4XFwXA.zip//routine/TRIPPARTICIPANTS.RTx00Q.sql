create function TripParticipants(trip_id IN number)
    return set_of_participants as
    result set_of_participants;
begin
    if (tripExists(TripParticipants.trip_id)) = false then
        raise_application_error(-20001, 'No such trip exists!');
    end if;
    select trip_participant(COUNTRY, TRIP_DATE, NAME, FIRSTNAME, LASTNAME, STATUS)
    bulk collect
    into result
    from TRIP
             inner join RESERVATION R on TRIP.TRIP_ID = R.TRIP_ID
             inner join PERSON P on P.PERSON_ID = R.PERSON_ID
    where TRIP.TRIP_ID = TripParticipants.trip_id;
    return result;

end;
/

