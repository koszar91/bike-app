create TYPE trip_record as object
    (
        trip_name varchar2(64),
        country varchar2(64),
        trip_date DATE,
        no_places int ,
        no_available_places int

    )
/

