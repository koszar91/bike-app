create trigger TR_PROTECT_RESERVATIONS
    before delete
    on RESERVATION
    for each row
begin
        RAISE_APPLICATION_ERROR(-1999,'You cant delete reservation');

    end;
/

