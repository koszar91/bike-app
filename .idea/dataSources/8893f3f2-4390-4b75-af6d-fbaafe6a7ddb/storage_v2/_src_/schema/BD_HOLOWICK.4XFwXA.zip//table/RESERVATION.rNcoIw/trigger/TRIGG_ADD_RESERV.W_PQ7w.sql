create trigger TRIGG_ADD_RESERV
    after insert
    on RESERVATION
    for each row
begin
        insert into RESERVATIONLOG(RESERVATION_ID, RESERVATION_LOG_DATE, NEW_STATUS)
        values (:NEW.RESERVATION_ID,SYSDATE,:NEW.STATUS);

        update TRIP
            set TRIP.NO_AVAILABLE_PLACES = TRIP.NO_AVAILABLE_PLACES - 1
            where TRIP_ID = :NEW.TRIP_ID;
    end;
/

