create procedure ModifyNoPlaces(trip_id IN TRIP.TRIP_ID%TYPE, no_places in TRIP.TRIP_ID%TYPE)
is
begin
    if (tripExists(trip_id)) then
    if (NoOfReservedPlaces(trip_id) <= no_places ) then
        update TRIP t
            set t.NO_PLACES = ModifyNoPlaces.no_places
            where t.TRIP_ID = ModifyNoPlaces.trip_id;
        else
             RAISE_APPLICATION_ERROR(-20003,'Cant change number of places');
    end if;
    else
        RAISE_APPLICATION_ERROR(-20003,'No such trip exists');
    end if;

end;
/

