create FUNCTION AvailableTrips(country IN number, date_from IN DATE, date_to IN DATE)
return trip_table as result trip_table;
begin
    select trip_record(NAME,va.COUNTRY,TRIP_DATE,NO_PLACES,no_available_places)
    bulk collect
    into result
    from V_AvailableTrips va where TRIP_DATE between date_from and date_to and va.COUNTRY = AvailableTrips.country;
    return result;
end;
/

