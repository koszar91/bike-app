create function reservationExists(reservation_id IN number)
    return boolean
    is
    counter int ;
begin
     select count(*) into counter from RESERVATION r where r.RESERVATION_ID = reservationExists.reservation_id;
     return counter>0;
end;
/

