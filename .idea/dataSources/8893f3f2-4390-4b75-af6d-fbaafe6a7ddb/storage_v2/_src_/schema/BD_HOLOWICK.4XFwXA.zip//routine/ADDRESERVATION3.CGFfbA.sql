create procedure AddReservation3(trip_id IN TRIP.TRIP_ID%TYPE,
                                           person_id IN RESERVATION.PERSON_ID%TYPE)
    is
    available_places int;
begin
    IF (tripExists(trip_id) = True and personExists(person_id) = True) then

        select vt.no_available_places
        into available_places
        from V_Trips vt inner join TRIP T on vt.country = T.COUNTRY and T.TRIP_ID = AddReservation3.trip_id;
        IF (available_places > 0) then
            insert into RESERVATION (TRIP_ID, PERSON_ID, STATUS)
            values (AddReservation3.trip_id, AddReservation3.person_id, 'N');

        else
            RAISE_APPLICATION_ERROR(-20001, 'No available places');
        end if;
    else
        RAISE_APPLICATION_ERROR(-20001, 'No such trip or person exist');

    end if;

end;
/

