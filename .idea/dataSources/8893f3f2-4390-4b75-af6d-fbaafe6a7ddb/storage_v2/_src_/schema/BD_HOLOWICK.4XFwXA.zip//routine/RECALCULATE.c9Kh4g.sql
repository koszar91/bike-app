create procedure recalculate
    as
begin
    update TRIP t
    set t.NO_AVAILABLE_PLACES = t.NO_PLACES -
                                (select count(*)
                                 from RESERVATION r
                                 where r.TRIP_ID = t.TRIP_ID
                                   and r.STATUS not like 'C');
end;
/

