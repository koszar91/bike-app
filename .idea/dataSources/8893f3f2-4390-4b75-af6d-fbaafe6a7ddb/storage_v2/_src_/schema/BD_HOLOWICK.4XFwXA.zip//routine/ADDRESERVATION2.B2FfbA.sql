create procedure AddReservation2(trip_id IN TRIP.TRIP_ID%TYPE,
                                           person_id IN RESERVATION.PERSON_ID%TYPE)
    is
    available_places int;
    newest_reservation_id int ;
begin
    IF (tripExists(trip_id) = True and personExists(person_id) = True) then

        select vt.no_available_places
        into available_places
        from V_Trips vt inner join TRIP T on vt.country = T.COUNTRY and T.TRIP_ID = AddReservation2.trip_id;
        IF (available_places > 0) then
            insert into RESERVATION (TRIP_ID, PERSON_ID, STATUS)
            values (AddReservation2.trip_id, AddReservation2.person_id, 'N');

            update TRIP
            set TRIP.NO_AVAILABLE_PLACES = TRIP.NO_AVAILABLE_PLACES - 1
            where TRIP_ID = AddReservation2.trip_id;

            select  r.RESERVATION_ID
            into newest_reservation_id
            from RESERVATION r
            where ROWNUM = 1
            order by r.RESERVATION_ID desc;


            insert into RESERVATIONLOG(RESERVATION_ID, RESERVATION_LOG_DATE, NEW_STATUS)
            values (newest_reservation_id,SYSDATE,'N' );
        else
            RAISE_APPLICATION_ERROR(-20001, 'No available places');
        end if;
    else
        RAISE_APPLICATION_ERROR(-20001, 'No such trip or person exist');

    end if;

end;
/

