create TYPE trip_participant as object
(
    country   varchar2(64),
    trip_date date,
    trip_name varchar2(64),
    firstname varchar2(64),
    lastname  varchar2(64),
    status    char(1)
)
/

